import React from 'react'
import './App.css'
import MyRoutes from './MyRoutes'


const App = () => {
  return (
    <>
      <MyRoutes/>
    </>
  )
}

export default App

