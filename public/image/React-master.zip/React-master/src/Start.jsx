import React from 'react'
import Nav from './Nav'

const Start = () => {
  return (
    <>
        <Nav/>
    </>
  )
}

export default Start